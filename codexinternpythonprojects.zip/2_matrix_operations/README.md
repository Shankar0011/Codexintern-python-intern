# Project 2: Matrix Operations Tool

## Objective:
Perform basic matrix operations through a console interface using NumPy.

## Features:
- Matrix addition, subtraction, multiplication
- Transpose and determinant
- User-friendly input

## How to Run:
```bash
pip install numpy
python matrix_tool.py
```
