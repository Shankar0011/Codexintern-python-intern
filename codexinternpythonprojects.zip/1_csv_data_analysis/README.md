# Project 1: CSV Data Analysis & Visualization

## Objective:
Analyze a CSV file using Pandas and visualize the results using Matplotlib and Seaborn.

## Features:
- Displays data summary
- Calculates average of a selected numeric column
- Bar chart, scatter plot, and correlation heatmap

## How to Run:
```bash
pip install pandas matplotlib seaborn
python csv_analysis.py
```

## Input:
Ensure the file `data.csv` is in the same folder.
