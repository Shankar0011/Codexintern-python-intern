# CODEXINTERN Python Projects – July 2025

This repository contains three Python projects completed for the CODEXINTERN July Internship Program.

## 🔰 Projects Included

### 1️⃣ [CSV Data Analysis & Visualization](./1_csv_data_analysis)
- Analyze CSV file with Pandas
- Visualize data using Matplotlib & Seaborn

### 2️⃣ [Matrix Operations Tool](./2_matrix_operations)
- Perform matrix addition, subtraction, multiplication, transpose, determinant
- Built using NumPy

### 3️⃣ [Voice-Activated Personal Assistant (Offline)](./3_voice_assistant_offline)
- Voice-controlled assistant
- Opens websites, tells time, plays music, sets reminders
- Works without any internet or API

## 📅 Internship Info
- **Organization**: CODEXINTERN
- **Domain**: Python Development
- **Duration**: July 1 – July 31, 2025
- **Level**: 2 Beginner + 1 Intermediate

## 🛠️ Setup Instructions
Each project folder has its own `README.md` with setup steps and documentation.
